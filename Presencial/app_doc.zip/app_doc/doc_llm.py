# Python 3.10
# pip3.10 install langchain_community
# pip3.10 install sentence-transformers
# pip3.10 install requests
# pip3.10 install nltk
# pip3.10 install chromadb

import os
import nltk
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_community.vectorstores import Chroma
from langchain.embeddings import HuggingFaceEmbeddings  # Usando HuggingFaceEmbeddings
import requests

# Certifique-se de que os recursos do NLTK estão baixados
nltk.download("punkt")
nltk.download("stopwords")

# Definir o caminho da pasta com os documentos
PASTA_DOCUMENTOS = "documents"  # Coloque o caminho correto para a pasta de documentos

# Função para carregar documentos PDF e TXT
def carregar_documentos():
    documentos = []
    for arquivo in os.listdir(PASTA_DOCUMENTOS):
        caminho_arquivo = os.path.join(PASTA_DOCUMENTOS, arquivo)
        if arquivo.endswith(".pdf"):
            loader = PyPDFLoader(caminho_arquivo)
        elif arquivo.endswith(".txt"):
            loader = TextLoader(caminho_arquivo)
        else:
            continue
        documentos.extend(loader.load())
    return documentos

# Usar HuggingFaceEmbeddings para gerar embeddings (em vez de SentenceTransformer diretamente)
model_id = "sentence-transformers/all-MiniLM-L6-v2"  # O modelo Hugging Face diretamente
embeddings = HuggingFaceEmbeddings(model_name=model_id)  # Usar o HuggingFaceEmbeddings da LangChain

# Criar o índice vetorial usando Chroma
def criar_indice(documentos):
    # Criar o índice com Chroma e HuggingFaceEmbeddings
    index = Chroma.from_documents(documentos, embeddings)
    return index

# Função para realizar a busca e gerar o contexto
def buscar_documentos(pergunta: str, index):
    # Realiza a busca nos documentos usando o índice
    resultado_busca = index.similarity_search(pergunta, k=1)  # Buscar pelos top 3 resultados mais relevantes
    print(resultado_busca)
    return resultado_busca

# Função para enviar a pergunta ao modelo LLaMA com o contexto
OLLAMA_URL = "http://localhost:11434/api/generate"

def obter_resposta_llama(pergunta: str, contexto: str) -> str:
    """Obtém a resposta do modelo LLaMA utilizando o contexto"""
    prompt = f"{contexto}\n\nPergunta: {pergunta}"
    payload = {
        "model": "gemma3:1b",
        "prompt": prompt,
        "stream": False
    }
    resposta = requests.post(OLLAMA_URL, json=payload)
    return resposta.json().get("response", "Erro ao obter resposta")

# Função para processar a pergunta e gerar a resposta
def processar_pergunta(pergunta: str, index):
    # Buscar documentos relevantes
    resultado_busca = buscar_documentos(pergunta, index)
    
    # Criar o contexto a partir dos documentos encontrados
    contexto = " ".join([res.page_content for res in resultado_busca])  # Acesse 'page_content' diretamente
    
    # Obter resposta do LLaMA com o contexto
    resposta_llama = obter_resposta_llama(pergunta, contexto)
    
    return resposta_llama

# Carregar documentos e criar o índice
documentos = carregar_documentos()
index = criar_indice(documentos)

if __name__ == "__main__":
    while True:
        pergunta = input("Digite sua pergunta (ou 'sair' para encerrar): ")
        if pergunta.lower() == "sair":
            break
        resposta = processar_pergunta(pergunta, index)
        print("Resposta do Assistente:", resposta)
